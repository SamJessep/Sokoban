package nz.ac.ara.srj0070.model;

public class Crate extends Placeable {
	
	public Crate(int x, int y) {
		super(x, y);
	}
	
	public String toString() {
		return "x";
	}



}
